import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class homepage {

	public static void main(String[] args) throws InterruptedException {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://norisushi.md");
        driver.manage().window().maximize();
        driver.findElement(By.xpath("//*[@id=\"body\"]/div[1]/div/div[3]/button")).click();
        driver.findElement(By.xpath("//*[@id=\"body\"]/main/div/div/div/div[1]/div/ul/li[1]/a")).click();
        Thread.sleep(1500);
        driver.findElement(By.xpath("//*[@id=\"promotions\"]/div[2]/div[1]/div[2]/div[1]/div/img")).click();
        Thread.sleep(1500);
        driver.findElement(By.xpath("//*[@id=\"dialog__result\"]/div[1]/div/div[2]/div[2]/div[3]/button/span[1]")).click();
        Actions actions = new Actions(driver);
        actions.moveByOffset(10, 10).click().perform();
        driver.findElement(By.xpath("//*[@id=\"shopping-cart-sidebar\"]/div/div/div[4]/div[2]/a")).click();
       //date introduse
        driver.findElement(By.xpath("//*[@id='cart-name']")).sendKeys("Victor Arab");
        driver.findElement(By.xpath("//*[@id='cart-phone']")).sendKeys("089766666");
        driver.findElement(By.xpath("//*[@id='cart-email']")).sendKeys("ivan.oleg44444@mail.ru");
        //butoane "cantitati"
        driver.findElement(By.xpath("//*[@id=\"form--shopping-cart\"]/div/div[1]/div[2]/div/div/div[4]/div/div[1]/div/button[2]")).click();
        driver.findElement(By.xpath("//*[@id=\"form--shopping-cart\"]/div/div[1]/div[2]/div/div/div[4]/div/div[2]/div/button[2]")).click();
       //selectarea modului de livrare
        driver.findElement(By.xpath("//*[@id=\"form--shopping-cart\"]/div/div[1]/div[3]/div[1]/div[2]/label")).click();
        Thread.sleep(2500);
        driver.findElement(By.xpath("//*[@id=\"tab-pane-order-pickup\"]/div/div/div/div[1]/div[1]")).click();
        driver.findElement(By.xpath("//*[@id=\"tab-pane-order-pickup\"]/div/div/div/div[1]/div[2]/div/div[2]")).click();
       //metoda de plata
        driver.findElement(By.xpath("//*[@id=\"form--shopping-cart\"]/div/div[1]/div[4]/div[1]/div/div[1]/label")).click();
        Thread.sleep(1000);
        //bifa "Sunt de acord..."
        WebElement checkbox = driver.findElement(By.id("app-rules-cart"));
        if (!checkbox.isSelected()) {
            Actions actions1 = new Actions(driver);
            actions1.moveToElement(checkbox).click().perform();
        }
        Thread.sleep(3000);
      //nu doresc sa fiu sunat
        driver.findElement(By.xpath("//*[@id=\"shopping-cart-sidebar\"]/div/div/div[3]/div[2]/div[3]/div")).click();
        Thread.sleep(3000);
      //finalizare comanda
        driver.findElement(By.xpath("//*[@id=\"shopping-cart-sidebar\"]/div/div/div[3]/div[2]/button")).click();
	}

}
